﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U3_8_Turistu_informacijos_centras
{
    // Klasė skirta Paminklams
    class Paminklas : LankytinaVieta
    {
        // Autorius
        public string Author { get; set; }
        // Paminklas skirtas
        public string Dedic { get; set; }

        public Paminklas()
        {

        }
        
        /// <param name="author">Paminklo autorius</param>
        /// <param name="dedic">Paminklas skirtas</param>
        public Paminklas(string author, string dedic, string title, string addr, int year) : base(title, addr, year)
        {
            Author = author;
            Dedic = dedic;
        }
        public Paminklas(string data)
        : base(data)
        {
            SetData(data);
        }
        public override string ToString()
        {
            string eilute;
            eilute = string.Format("| {0, -29} | {1, -21} | {2, 5} | {3, -20} | {4, -22} |", Title, Addr, Year, Dedic, Author);

            return eilute;
        }

        public override bool GetGuide()
        {
            throw new NotImplementedException();
        }
    }
}
