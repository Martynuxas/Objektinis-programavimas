﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U3_8_Turistu_informacijos_centras
{
    // Klasė skirta Muziejams
    class Museum : LankytinaVieta
    {
        // Muziejaus tipas
        public string Type { get; set; }
        // Darbo dienos
        public bool[] Open { get; set; } = new bool[7];
        // Ar turi gidą
        public bool Guide { get; set; }
        // Bilieto kaina
        public double Price { get; set; }

        public Museum()
        {

        }

        /// <param name="type">Muziejaus tipas</param>
        /// <param name="open">Darbo dienos</param>
        /// <param name="guide">Ar turi gidą</param>
        /// <param name="price">Bilieto kaina</param>
        public Museum(string type, bool[] open, bool guide, double price, string title, string addr, int year) : base(title, addr, year)
        {
            Type = type;
            Open = open;
            Guide = guide;
            Price = price;
        }
        public Museum(string data)
        : base(data)
        {
            SetData(data);
        }
        public override string ToString()
        {
            string eilute;
            eilute = string.Format("| {0, -36} | {1, -25} | {2, 5} | {3, -10} | {4} | {5} | {6} | {7} | {8} | {9} | {10} | {11, -5} |  {12:f} |",
                    Title, Addr, Year, Type, Open[0].Equals(true) ? "+" : "-", Open[1].Equals(true) ? "+" : "-", Open[2].Equals(true) ? "+" : "-",
                    Open[3].Equals(true) ? "+" : "-", Open[4].Equals(true) ? "+" : "-", Open[5].Equals(true) ? "+" : "-",
                    Open[6].Equals(true) ? "+" : "-", Guide.Equals(true) ? "Yra" : "Nėra", Price);
            return eilute;
        }

        // Grąžina ar turi gidą
        public override bool GetGuide() {
            return Guide;
        }
    }
}
