﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U3_8_Turistu_informacijos_centras
{
    // Klasė skirta visoms lankytinoms vietoms
    class AllPlaces : LankytinaVieta
    {
        public AllPlaces()
        {

        }
        
        /// <param name="title">Pavadinimas</param>
        /// <param name="addr">Adresas</param>
        /// <param name="year">Pastatymo/įkurimo Metai</param>
        public AllPlaces(string title, string addr, int year) : base(title, addr, year)
        {

        }

        public override string ToString()
        {
            throw new NotImplementedException();
        }

        public override bool GetGuide()
        {
            throw new NotImplementedException();
        }
    }
}
