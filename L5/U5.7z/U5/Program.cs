﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U3_8_Turistu_informacijos_centras
{
    class Program
    {
        static void Main(string[] args)
        {
            // Randa visus duomenų failus
            string[] dFiles = Directory.GetFiles(@"Miestai", "*.txt").Select(Path.GetFileName).ToArray();

            if (dFiles.Count() != 0)
            {
                int MYears = 2;//Naujo muziejaus senumo metai
                int PYears = 1;//Naujo paminklo senumo metai

                // Muziejų konteineris
                PContainer MusCon = new PContainer();

                // Paminklų konteineris
                PContainer PamCon = new PContainer();

                //Naujų muziejų konteineris
                PContainer NewMuseumPlaces = new PContainer();

                //Naujų paminklų konteineris
                PContainer NewMonumentPlaces = new PContainer();

                // Visos lankytinos vietos
                PContainer AllPlaces = new PContainer();

                // Duomenų skaitymas
                ReadingData(MusCon, PamCon, dFiles);

                // Perskaitytų duomenų išvedimas
                ReadDataOutput(MusCon, PamCon);

                // Suskaičiuoja kiek muziejų turi gidus
                int GuidesNum = CountGuides(MusCon);
                Console.WriteLine("Gidus turi {0} muziejus(-ų)", GuidesNum);

                // Randa seniausią lankytiną vietą
                int[] op = OldestPlace(MusCon, PamCon);

                // Išveda seniausią lankytiną vietą į konsolę
                OlddestPlaceOutput(MusCon, PamCon, op);

                // Sukelia muziejus ir paminklus į vieną konteinerį
                FillAllPlacesCon(AllPlaces, MusCon, PamCon);

                // Visų lankytinų vietų rikiavimas
                SortingPlaces(AllPlaces);

                // Spausdina surikiuotas visas lankytinas vietas į VisosVietos.csv
                AllPlacesOutput(AllPlaces);

                // Sukelia visas naujas lankytinas vietas į viena konteinerį
                GetNewestPlaces(MusCon, PamCon, MYears, PYears, NewMuseumPlaces, NewMonumentPlaces);

                // Visų naujų muziejų rikiavimas
                NewMuseumPlaces.Rikiuoti_Pagal_Kaina();

                // Visų naujų paminklų rikiavimas
                NewMonumentPlaces.Rikiuoti_Pagal_Autoriu();

                // Spausdina surikiuotas visas naujas lankytinas vietas į Nauji.csv
                AllNewPlacesOutput(NewMuseumPlaces, NewMonumentPlaces);
            }
            else
            {
                Console.WriteLine("Nėra duomenų failų");
            }

            Console.ReadKey();
        }

        /// <summary>
        /// Duomenų skaitymas
        /// </summary>
        /// <param name="MusCon">Muziejų konteineris</param>
        /// <param name="PamCon">Paminklų konteineris</param>
        /// <param name="dFiles">Skaitomo failo pavadinimas</param>
        static void ReadingData(PContainer MusCon, PContainer PamCon, string[] dFiles)
        {
            foreach (var file in dFiles)
            {
                string[] lines = File.ReadAllLines(@"Miestai/" + file);

                foreach (var line in lines)
                {
                    string[] value = line.Split(';');

                    if(value[0].Equals("M"))
                    {
                        // Pridedam muziejus i konteineri
                        string title = value[1].Trim();
                        string addr = value[2].Trim();
                        int year = int.Parse(value[3]);
                        string type = value[4].Trim();
                        bool[] open = new bool[7];
                        for (int i = 0; i < 7; i++)
                        {
                            open[i] = value[5 + i].Equals(" 1") ? true : false;
                        }
                        bool guide = value[12].Trim().Equals("taip") ? true : false;
                        double price = double.Parse(value[13]);

                        Museum museum = new Museum(type, open, guide, price, title, addr, year);

                        MusCon.AddPlace(museum);
                    }
                    else if (value[0].Equals("P"))
                    {
                        // Pridedam paminklus i konteineri
                        string title = value[1].Trim();
                        string addr = value[2].Trim();
                        int year = int.Parse(value[3]);
                        string dedic = value[4].Trim();
                        string author = value[5].Trim();

                        Paminklas paminklas = new Paminklas(author, dedic, title, addr, year);

                        PamCon.AddPlace(paminklas);
                    }
                }
            }
        }

        /// <summary>
        /// Perskaitytų duomenų išvedimas
        /// </summary>
        /// <param name="MusCon">Muziejų konteineris</param>
        /// <param name="PamCon">Paminklų konteineris</param>
        static void ReadDataOutput(PContainer MusCon, PContainer PamCon)
        {
            using (var writer = new StreamWriter("Duomenys.txt", false, Encoding.UTF8))
            {
                writer.WriteLine("Muziejai:");
                writer.WriteLine("+-----------------------------------------------------------------------------------------------------------------------------------+");
                writer.WriteLine("|             Pavadinimas              |          Adresas          | Metai |   Tipas    | P | A | T | K | P | Š | S | Gidas | Kaina |");

                for (int i = 0; i < MusCon.Count; i++)
                {
                    writer.WriteLine("|--------------------------------------|---------------------------|-------|------------|---|---|---|---|---|---|---|-------|-------|");
                    writer.WriteLine(MusCon.GetPlace(i).ToString());
                }
                writer.WriteLine("+-----------------------------------------------------------------------------------------------------------------------------------+");


                writer.WriteLine();
                writer.WriteLine("Paminklai:");
                writer.WriteLine("+---------------------------------------------------------------------------------------------------------------+");
                writer.WriteLine("|          Pavadinimas          |        Adresas        | Metai |        Skirta        |        Autorius        |");

                for (int i = 0; i < PamCon.Count; i++)
                {
                    writer.WriteLine("|-------------------------------|-----------------------|-------|----------------------|------------------------|");
                    writer.WriteLine(PamCon.GetPlace(i).ToString());
                }
                writer.WriteLine("+---------------------------------------------------------------------------------------------------------------+");
            }
        }

        /// <summary>
        /// Suskaičiuoja kiek muziejų turi gidus
        /// </summary>
        /// <param name="MusCont">Muziejų konteineris</param>
        /// <returns>Gražina suskaičiuotų gidų skaičių</returns>
        static int CountGuides(PContainer MusCont)
        {
            int num = 0;

            for (int i = 0; i < MusCont.Count; i++)
            {
                if(MusCont.GetPlace(i).GetGuide() == true)
                {
                    num++;
                }
            }

            return num;
        }

        /// <summary>
        /// Randa seniausią lankytiną vietą
        /// </summary>
        /// <param name="MusCon">Muziejų konteineris</param>
        /// <param name="PamCon">Paminklų konteineris</param>
        /// <returns>Gražina seniausią lankytina vietą</returns>
        static int[] OldestPlace(PContainer MusCon, PContainer PamCon)
        {
            // Pirmoj vietoj: 0/1 - muziejus/paminklas, antroj - jo id;
            int[] op = new int[2];
            int year = 9999;

            for (int i = 0; i < MusCon.Count; i++)
            {  
                if(year > MusCon.GetPlace(i).Year)
                {
                    year = MusCon.GetPlace(i).Year;
                    op[0] = 0;
                    op[1] = i;
                }
            }

            for (int i = 0; i < PamCon.Count; i++)
            {
                if (year > PamCon.GetPlace(i).Year)
                {
                    year = PamCon.GetPlace(i).Year;
                    op[0] = 1;
                    op[1] = i;
                }
            }

            return op;
        }

        /// <summary>
        /// Išveda seniausią lankytiną vietą į konsolę
        /// </summary>
        /// <param name="MusCon">Muziejų konteineris</param>
        /// <param name="PamCon">Paminklų konteineris</param>
        /// <param name="op">Seniausia lankytina vieta</param>
        static void OlddestPlaceOutput(PContainer MusCon, PContainer PamCon, int[] op)
        {
            if (op[0] == 0)
            {
                Console.WriteLine();
                Console.WriteLine("Seniausia lankytina vieta yra muziejus:");
                Console.WriteLine("+-----------------------------------------------------------------------------------------------------------------------------------+");
                Console.WriteLine("|             Pavadinimas              |          Adresas          | Metai |   Tipas    | P | A | T | K | P | Š | S | Gidas | Kaina |");
                Console.WriteLine("|--------------------------------------|---------------------------|-------|------------|---|---|---|---|---|---|---|-------|-------|");
                Console.WriteLine(MusCon.GetPlace(op[1]).ToString());
                Console.WriteLine("+-----------------------------------------------------------------------------------------------------------------------------------+");
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Seniausia lankytina vieta yra paminklas:");
                Console.WriteLine("+---------------------------------------------------------------------------------------------------------------+");
                Console.WriteLine("|          Pavadinimas          |        Adresas        | Metai |        Skirta        |        Autorius        |");
                Console.WriteLine("|-------------------------------|-----------------------|-------|----------------------|------------------------|");
                Console.WriteLine(PamCon.GetPlace(op[1]).ToString());
                Console.WriteLine("+---------------------------------------------------------------------------------------------------------------+");
            }
        }

        /// <summary>
        /// Sukelia muziejus ir paminklus į vieną konteinerį
        /// </summary>
        /// <param name="AllPlaces">Visų lankytinų vietų konteineris</param>
        /// <param name="MusCon">Muziejų konteineris</param>
        /// <param name="PamCon">Paminklų konteineris</param>
        static void FillAllPlacesCon(PContainer AllPlaces, PContainer MusCon, PContainer PamCon)
        {
            for (int i = 0; i < MusCon.Count; i++)
            {
                AllPlaces lv = new AllPlaces(MusCon.GetPlace(i).Title, "", MusCon.GetPlace(i).Year);
                AllPlaces.AddPlace(lv);
            }
            for (int i = 0; i < PamCon.Count; i++)
            {
                AllPlaces lv = new AllPlaces(PamCon.GetPlace(i).Title, "", PamCon.GetPlace(i).Year);
                AllPlaces.AddPlace(lv);
            }
        }
            /// <summary>
            /// Visų lankytinų vietų rikiavimas
            /// </summary>
            /// <param name="AllPlaces">Visų lankytinų vietų konteineris</param>
            static void SortingPlaces(PContainer AllPlaces)
            {
            int year;
            string title;
            for (int i = 0; i < AllPlaces.Count; i++)
            {
                for (int j = 0; j < AllPlaces.Count; j++)
                {
                    if (AllPlaces.GetPlace(i).Year < AllPlaces.GetPlace(j).Year)
                    {
                        year = AllPlaces.GetPlace(i).Year;
                        AllPlaces.GetPlace(i).Year = AllPlaces.GetPlace(j).Year;
                        AllPlaces.GetPlace(j).Year = year;

                        title = AllPlaces.GetPlace(i).Title;
                        AllPlaces.GetPlace(i).Title = AllPlaces.GetPlace(j).Title;
                        AllPlaces.GetPlace(j).Title = title;
                    }
                }
            }

            for (int i = 0; i < AllPlaces.Count; i++)
            {
                for (int j = 0; j < AllPlaces.Count; j++)
                {
                    if (AllPlaces.GetPlace(i).Title.CompareTo(AllPlaces.GetPlace(j).Title) < 0)
                    {
                        title = AllPlaces.GetPlace(i).Title;
                        AllPlaces.GetPlace(i).Title = AllPlaces.GetPlace(j).Title;
                        AllPlaces.GetPlace(j).Title = title;

                        year = AllPlaces.GetPlace(i).Year;
                        AllPlaces.GetPlace(i).Year = AllPlaces.GetPlace(j).Year;
                        AllPlaces.GetPlace(j).Year = year;
                    }
                }
            }
        }

        /// <summary>
        /// // Spausdina surikiuotas visas lankytinas vietas į VisosVietos.csv
        /// </summary>
        /// <param name="AllPlaces">Visų lankytinų vietų konteineris</param>
        static void AllPlacesOutput(PContainer AllPlaces)
        {
            using (var writer = new StreamWriter("VisosVietos.csv", false, Encoding.UTF8))
            {
                for (int i = 0; i < AllPlaces.Count; i++)
                {
                    writer.WriteLine(AllPlaces.GetPlace(i).Title);
                }

                writer.Close();
            }
        }

        /// <summary>
        /// // Spausdina surikiuotas visas lankytinas vietas į Nauji.csv
        /// </summary>
        /// <param name="NewMuseumPlaces">Naujų muziejų konteineris</param>
        /// <param name="NewMonumentPlaces">Naujų paminklų konteineris</param>
        static void AllNewPlacesOutput(PContainer NewMuseumPlaces, PContainer NewMonumentPlaces)
        {
            using (var writer = new StreamWriter("Nauji.csv", false, Encoding.UTF8))
            {
                string rez = "nera";

                for (int i = 0; i < NewMuseumPlaces.Count; i++)
                {
                    rez = NewMuseumPlaces.GetPlace(i).ToString();
                    writer.WriteLine(NewMuseumPlaces.GetPlace(i).ToString().Trim('|').Replace('|', ';'));
                }

                for (int i = 0; i < NewMonumentPlaces.Count; i++)
                {
                    rez = NewMonumentPlaces.GetPlace(i).ToString();
                    writer.WriteLine(NewMonumentPlaces.GetPlace(i).ToString().Trim('|').Replace('|', ';'));
                }

                if (rez == "nera")
                    writer.WriteLine("Nėra nei vienos naujos lankytinos vietos");
                writer.Close();
            }
        }
        /// <summary>
        /// Suveda naujus muziejus/paminklus į atskirus konteinerius
        /// </summary>
        /// <param name="MusCon">Muziejų konteineris</param>
        /// <param name="PamCon">Paminklų konteineris</param>
        /// <param name="MYears">Metai kiek dar būna naujas muziejus</param>
        /// <param name="PYears">Metai kiek dar būna naujas paminklas</param>
        /// <param name="NewMuseumPlaces">Naujų muziejų konteineris</param>
        /// <param name="NewMonumentPlaces">Naujų paminklų konteineris</param>
        static void GetNewestPlaces(PContainer MusCon, PContainer PamCon, int MYears, int PYears, PContainer NewMuseumPlaces, PContainer NewMonumentPlaces)
        {
            double years = DateTime.Now.Year;

            for (int i = 0; i < MusCon.Count; i++)
            {
                if ((years - MusCon.GetPlace(i).Year) < MYears)
                {
                    NewMuseumPlaces.AddPlace(MusCon.GetPlace(i));
                }
            }

            for (int i = 0; i < PamCon.Count; i++)
            {
                if ((years - PamCon.GetPlace(i).Year) < PYears)
                {
                    NewMonumentPlaces.AddPlace(PamCon.GetPlace(i));
                }
            }
        }
    }
}
