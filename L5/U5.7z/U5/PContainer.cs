﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U3_8_Turistu_informacijos_centras
{
    // Muziejų, paminklų, lankytinų vietų konteineris
    class PContainer
    {
        private LankytinaVieta[] LankVietos;

        public int Count { get; private set; }

        public PContainer(int dydis = 999)
        {
            LankVietos = new LankytinaVieta[dydis];
            Count = 0;
        }

        public void AddPlace(LankytinaVieta lankVieta)
        {
            LankVietos[Count++] = lankVieta;
        }

        public LankytinaVieta GetPlace(int indeksas)
        {
            return LankVietos[indeksas];
        }
        public bool Contains(LankytinaVieta objektas)
        {
            return LankVietos.Contains(objektas);
        }

        public void Rikiuoti_Pagal_Autoriu()
        {
            for (int i = 0; i < Count - 1; i++)
            {
                for (int j = i + 1; j < Count; j++)
                {
                    LankytinaVieta laikinas = LankVietos[i];
                    if (GetPlace(j) < GetPlace(i))
                    {
                        LankVietos[i] = LankVietos[j];
                        LankVietos[j] = laikinas;
                    }
                }
            }
        }
        public void Rikiuoti_Pagal_Kaina()
        {
            for (int i = 0; i < Count; i++)
            {
                for (int j = 0; j < Count; j++)
                {
                    LankytinaVieta laikinas = LankVietos[i];
                    if ((GetPlace(j) as Museum).Price < (GetPlace(i) as Museum).Price || ((GetPlace(j) as Museum).Price == (GetPlace(i) as Museum).Price))
                    {
                        LankVietos[i] = LankVietos[j];
                        LankVietos[j] = laikinas;
                    }
                }
            }
        }
    }
}