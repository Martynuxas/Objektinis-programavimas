﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U3_8_Turistu_informacijos_centras
{
    // Lankytinų vietų bazinė klasė
    abstract class LankytinaVieta : Object
    {
        // Pavadinimas
        public string Title { get; set; }
        // Adresas
        public string Addr { get; set; }
        // Metai
        public int Year { get; set; }

        public LankytinaVieta()
        {

        }

        /// <param name="title">Paminklo/muziejaus pavadinimas</param>
        /// <param name="addr">Adresas</param>
        /// <param name="year">Pastatymo/įkūrimo Metai</param>
        public LankytinaVieta(string title, string addr, int year)
        {
            Title = title;
            Addr = addr;
            Year = year;
        }
        public LankytinaVieta(string data)
        {
            SetData(data);
        }        public virtual void SetData(string line)
        {
            string[] values = line.Split(',');
            Title = values[1];
            Addr = values[2];
        }
        public override bool Equals(object obj)
        {
            return this.Equals(obj as LankytinaVieta);
        }

        public bool Equals(LankytinaVieta lankytinaVieta)
        {
            if (Object.ReferenceEquals(lankytinaVieta, null))
            {
                return false;
            }
            if (this.GetType() != lankytinaVieta.GetType())
            {
                return false;
            }
            return (Addr == lankytinaVieta.Addr) && (Title == lankytinaVieta.Title);
        }

        public override int GetHashCode()
        {
            return Addr.GetHashCode() ^ Title.GetHashCode();
        }

        public static bool operator <(LankytinaVieta objektas1, LankytinaVieta objektas2)
        {
                if (String.Compare((objektas1 as Paminklas).Author, (objektas2 as Paminklas).Author, StringComparison.CurrentCulture) < 0)
                return true;
            return false;
        }

        public static bool operator >(LankytinaVieta objektas1, LankytinaVieta objektas2)
        {
            if (String.Compare((objektas1 as Paminklas).Author, (objektas2 as Paminklas).Author, StringComparison.CurrentCulture) > 0)
                return true;
            return false;
        }
        abstract public override string ToString();

        abstract public bool GetGuide();
    }
}
